package it.swingradar.italia.v11;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.List;

/** Optional, factual financial metrics. Never controls technical signal confirmation. */
final class Fundamentals {
    private static final long TWELVE_HOURS=12L*60L*60L*1000L;
    private static final String[] COLUMNS={
        "sector","market_cap_basic","price_earnings_ttm","return_on_equity_fq",
        "debt_to_equity_fq","total_revenue_yoy_growth_ttm","net_margin_ttm","price_book_fq"
    };
    private Fundamentals(){}
    static void refresh(Context context,List<String[]> universe){
        SharedPreferences prefs=context.getSharedPreferences("fundamentals_v12",0);
        long last=prefs.getLong("checked_at",0);
        long delay=prefs.getString("error","").isEmpty()?TWELVE_HOURS:20L*60L*1000L;
        if(last>0&&System.currentTimeMillis()-last<delay)return;
        try{
            JSONObject values=request(universe);
            if(values.length()==0)throw new Exception("Nessuna società con metriche disponibili");
            prefs.edit().putString("values",values.toString())
                .putLong("checked_at",System.currentTimeMillis())
                .putString("updated_at",Instant.now().toString())
                .putString("error","").apply();
        }catch(Exception e){
            // Keep last known metrics, but expose failure and age; never synthesize numbers.
            prefs.edit().putString("error",e.getClass().getSimpleName()+": "+e.getMessage())
                .putLong("checked_at",System.currentTimeMillis()).apply();
        }
    }
    private static JSONObject request(List<String[]> universe)throws Exception{
        JSONArray symbols=new JSONArray();
        for(String[] x:universe)symbols.put("MIL:"+x[0]);
        JSONObject request=new JSONObject().put("symbols",new JSONObject().put("tickers",symbols));
        JSONArray cols=new JSONArray();for(String col:COLUMNS)cols.put(col);
        request.put("columns",cols);
        HttpURLConnection conn=(HttpURLConnection)new URL("https://scanner.tradingview.com/italy/scan").openConnection();
        try{
            conn.setConnectTimeout(11000);conn.setReadTimeout(18000);
            conn.setRequestMethod("POST");conn.setDoOutput(true);
            conn.setRequestProperty("Content-Type","application/json; charset=utf-8");
            conn.setRequestProperty("Accept","application/json");
            conn.setRequestProperty("User-Agent","Mozilla/5.0 (Android; SwingRadarItalia private research)");
            try(OutputStream out=conn.getOutputStream()){
                out.write(request.toString().getBytes(StandardCharsets.UTF_8));
            }
            int status=conn.getResponseCode();if(status!=200)throw new Exception("HTTP "+status);
            ByteArrayOutputStream bytes=new ByteArrayOutputStream();
            try(InputStream in=conn.getInputStream()){
                byte[] buffer=new byte[8192];int n;
                while((n=in.read(buffer))!=-1){bytes.write(buffer,0,n);if(bytes.size()>700_000)throw new Exception("Risposta finanziaria eccessiva");}
            }
            JSONArray data=new JSONObject(bytes.toString("UTF-8")).optJSONArray("data");
            if(data==null)throw new Exception("Formato dati fondamentali cambiato");
            JSONObject results=new JSONObject();
            for(int i=0;i<data.length();i++){
                JSONObject row=data.optJSONObject(i);if(row==null)continue;
                String symbol=row.optString("s","");
                if(!symbol.startsWith("MIL:"))continue;
                String ticker=symbol.substring(4);
                JSONArray values=row.optJSONArray("d");if(values==null||values.length()!=COLUMNS.length)continue;
                JSONObject metrics=new JSONObject();
                for(int j=0;j<COLUMNS.length;j++){
                    if(!values.isNull(j))metrics.put(COLUMNS[j],values.get(j));
                }
                if(metrics.length()>0)results.put(ticker,metrics);
            }
            return results;
        }finally{conn.disconnect();}
    }
    static JSONObject status(Context context){
        SharedPreferences prefs=context.getSharedPreferences("fundamentals_v12",0);
        JSONObject state=new JSONObject();
        try{
            JSONObject values=new JSONObject(prefs.getString("values","{}"));
            state.put("values",values).put("count",values.length())
                .put("updatedAt",prefs.getString("updated_at",""))
                .put("lastError",prefs.getString("error",""));
        }catch(Exception ignored){}
        return state;
    }
}
